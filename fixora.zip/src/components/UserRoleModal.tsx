import React from 'react';
import { 
  X, 
  Users, 
  Briefcase, 
  Building2, 
  ShieldCheck, 
  CheckCircle2, 
  Layers, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { UserRole } from '../types';
import { USER_ROLES_INFO } from '../data/mockData';

interface UserRoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
}

export const UserRoleModal: React.FC<UserRoleModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  onSelectRole,
}) => {
  if (!isOpen) return null;

  const roleDetails = {
    citizen: {
      phaseRole: 'Citizen & Public User',
      phaseRoadmap: [
        { phase: 'Phase 1 (Current)', desc: 'Category exploration, problem reporting draft UI, tracking milestone preview.' },
        { phase: 'Phase 2', desc: 'End-to-end problem submission engine, location geo-tagging, urgent flag assignment.' },
        { phase: 'Phase 3', desc: 'Citizen accounts, saved complaints, direct service professional chat, personalized alerts.' },
        { phase: 'Phase 4', desc: 'Live ticket tracking timeline, push notifications, customer satisfaction rating.' },
        { phase: 'Phase 5', desc: 'Final production sync, offline PWA, multi-language support.' },
      ],
    },
    provider: {
      phaseRole: 'Verified Service Provider',
      phaseRoadmap: [
        { phase: 'Phase 1 (Current)', desc: 'Public skill directory display, profile preview, availability badges.' },
        { phase: 'Phase 2', desc: 'Service request lead intake, scope estimation form.' },
        { phase: 'Phase 3', desc: 'Provider onboarding, trade certification verification, job acceptance dashboard.' },
        { phase: 'Phase 4', desc: 'Live job scheduling, client invoicing, digital work completion receipts.' },
        { phase: 'Phase 5', desc: 'Earnings analytics, payout integration, customer review management.' },
      ],
    },
    authority: {
      phaseRole: 'Department & Civic Authority Officer',
      phaseRoadmap: [
        { phase: 'Phase 1 (Current)', desc: 'Departmental triage classification mapping, resolution SLA modeling.' },
        { phase: 'Phase 2', desc: 'Automated civic ticket ingestion from citizen grievance portal.' },
        { phase: 'Phase 3', desc: 'Nodal officer credentials, jurisdictional ward demarcation, escalation policies.' },
        { phase: 'Phase 4', desc: 'Ward-level resolution dashboard, field inspection photo proof, clearance status.' },
        { phase: 'Phase 5', desc: 'Civic SLA performance heatmaps, public transparency reports.' },
      ],
    },
    admin: {
      phaseRole: 'Fixora Platform Administrator',
      phaseRoadmap: [
        { phase: 'Phase 1 (Current)', desc: 'Taxonomy governance across 7 sectors and 60+ subcategories.' },
        { phase: 'Phase 2', desc: 'Grievance routing pipeline rules, duplicate ticket deduplication.' },
        { phase: 'Phase 3', desc: 'Service professional background check approval workflow.' },
        { phase: 'Phase 4', desc: 'Real-time metrics on resolution times, SLA violations, high-frequency problem hotspots.' },
        { phase: 'Phase 5', desc: 'Database security audits, role-based access control, disaster recovery.' },
      ],
    },
  };

  const currentInfo = roleDetails[currentRole];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wider">
                Fixora 5-Phase Architecture
              </span>
              <h3 className="font-['Outfit',sans-serif] text-lg sm:text-xl font-bold text-slate-900">
                Persona Portal Roadmap
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Role Selector Tabs */}
        <div className="p-4 bg-slate-100/60 border-b border-slate-200/80">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {USER_ROLES_INFO.map((r) => (
              <button
                key={r.role}
                onClick={() => onSelectRole(r.role)}
                className={`p-2 rounded-xl text-xs font-semibold transition-all text-center cursor-pointer ${
                  currentRole === r.role
                    ? 'bg-white text-indigo-700 shadow-sm border border-indigo-200'
                    : 'bg-transparent text-slate-600 hover:bg-white/50'
                }`}
              >
                {r.title.split('/')[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Roadmap content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-['Outfit',sans-serif] text-base font-bold text-slate-900">
              {currentInfo.phaseRole} Roadmap
            </h4>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
              Phase 1 Foundation Active
            </span>
          </div>

          <div className="space-y-3 pt-2">
            {currentInfo.phaseRoadmap.map((item, idx) => (
              <div
                key={idx}
                className={`p-3.5 rounded-xl border transition-colors ${
                  idx === 0 
                    ? 'bg-indigo-50/70 border-indigo-200' 
                    : 'bg-slate-50/60 border-slate-200/80'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-xs font-bold ${idx === 0 ? 'text-indigo-800' : 'text-slate-700'}`}>
                    {item.phase}
                  </span>
                  {idx === 0 && (
                    <span className="text-[10px] font-bold text-indigo-700 uppercase bg-white px-2 py-0.5 rounded shadow-2xs">
                      Live in UI
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Extensible codebase designed for seamless Phase 2-5 onboarding.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-700 transition-colors"
          >
            Acknowledge & Continue
          </button>
        </div>

      </div>
    </div>
  );
};
