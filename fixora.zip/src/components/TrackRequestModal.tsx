import React, { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  Compass, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  MapPin, 
  Building2, 
  ShieldCheck,
  ArrowRight
} from 'lucide-react';
import { SAMPLE_TRACKING_RECORDS } from '../data/mockData';
import { TrackingRecord } from '../types';

interface TrackRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTrackingId?: string | null;
}

export const TrackRequestModal: React.FC<TrackRequestModalProps> = ({
  isOpen,
  onClose,
  initialTrackingId,
}) => {
  const [searchId, setSearchId] = useState<string>('FX-2026-9481');
  const [currentRecord, setCurrentRecord] = useState<TrackingRecord | null>(
    SAMPLE_TRACKING_RECORDS['FX-2026-9481']
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (initialTrackingId) {
      setSearchId(initialTrackingId);
      if (SAMPLE_TRACKING_RECORDS[initialTrackingId]) {
        setCurrentRecord(SAMPLE_TRACKING_RECORDS[initialTrackingId]);
        setErrorMsg(null);
      } else {
        // Construct simulated newly submitted ticket
        setCurrentRecord({
          trackingId: initialTrackingId,
          title: 'Recently Submitted Request via Fixora',
          category: 'Active Triage',
          subcategory: 'Priority Request',
          status: 'submitted',
          departmentOrProvider: 'Fixora Central Triage Desk (Routing to Nodal Officer)',
          reportedDate: 'Just now',
          updatedDate: 'Just now',
          estimatedResolution: 'Triage in progress (acknowledgment within 2 hours)',
          location: 'Reported Location',
          timeline: [
            { step: 1, title: 'Problem Logged via Fixora', desc: 'Request captured and queued in system.', timestamp: 'Just now', completed: true, current: true },
            { step: 2, title: 'Smart Authority / Provider Matching', desc: 'Auto-allocating to designated field wing.', timestamp: 'Pending', completed: false },
            { step: 3, title: 'On-Site Inspection / Dispatch', desc: 'Field officer or certified professional assigned.', timestamp: 'Pending', completed: false },
            { step: 4, title: 'Resolution & Citizen Sign-off', desc: 'Work completion verified and archived.', timestamp: 'Pending', completed: false },
          ],
        });
        setErrorMsg(null);
      }
    }
  }, [initialTrackingId, isOpen]);

  if (!isOpen) return null;

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const id = searchId.trim().toUpperCase();
    if (!id) return;

    if (SAMPLE_TRACKING_RECORDS[id]) {
      setCurrentRecord(SAMPLE_TRACKING_RECORDS[id]);
      setErrorMsg(null);
    } else {
      // Create a simulated record for any custom ID typed by the user
      setCurrentRecord({
        trackingId: id,
        title: `Grievance Request: ${id}`,
        category: 'Civic / Service Record',
        subcategory: 'Active Ticket',
        status: 'assigned',
        departmentOrProvider: 'Assigned Regional Service Desk',
        reportedDate: 'Today, 10:15 AM',
        updatedDate: 'Today, 11:30 AM',
        estimatedResolution: 'Within 48 hours',
        location: 'Designated Ward Area',
        timeline: [
          { step: 1, title: 'Complaint Registered', desc: 'System recorded ticket and notified dispatch.', timestamp: '10:15 AM', completed: true },
          { step: 2, title: 'Allocated to Technical Team', desc: 'Designated technician assigned to docket.', timestamp: '11:30 AM', completed: true, current: true },
          { step: 3, title: 'Site Inspection / Repair', desc: 'Field personnel visiting designated site.', timestamp: 'Estimated Today 03:00 PM', completed: false },
          { step: 4, title: 'Final Verification', desc: 'Citizen signoff & closure.', timestamp: 'Pending', completed: false },
        ],
      });
      setErrorMsg(null);
    }
  };

  const selectSampleId = (id: string) => {
    setSearchId(id);
    setCurrentRecord(SAMPLE_TRACKING_RECORDS[id]);
    setErrorMsg(null);
  };

  const getStatusBadge = (status: TrackingRecord['status']) => {
    switch (status) {
      case 'resolved':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'in_progress':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'assigned':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-['Outfit',sans-serif] text-lg sm:text-xl font-bold text-slate-900 leading-tight">
                Track Your Request
              </h3>
              <p className="text-xs text-slate-500">
                Live Status Tracker (Phase 1 Frontend Architecture)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Search Bar for Tracking */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                placeholder="Enter Ticket ID (e.g. FX-2026-9481)"
                className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 font-mono font-medium text-slate-800 uppercase"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-white bg-indigo-600 hover:bg-indigo-700 transition-colors flex items-center gap-1.5 cursor-pointer flex-shrink-0"
            >
              <span>Track</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Quick sample chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-slate-400 font-medium text-[11px] flex-shrink-0">
              Sample Tickets:
            </span>
            <button
              type="button"
              onClick={() => selectSampleId('FX-2026-9481')}
              className={`px-2.5 py-1 rounded-lg border font-mono text-[11px] transition-colors cursor-pointer whitespace-nowrap ${
                searchId === 'FX-2026-9481' ? 'bg-indigo-50 border-indigo-300 text-indigo-700 font-bold' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              FX-2026-9481 (Road Pothole)
            </button>
            <button
              type="button"
              onClick={() => selectSampleId('FX-2026-3108')}
              className={`px-2.5 py-1 rounded-lg border font-mono text-[11px] transition-colors cursor-pointer whitespace-nowrap ${
                searchId === 'FX-2026-3108' ? 'bg-indigo-50 border-indigo-300 text-indigo-700 font-bold' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              FX-2026-3108 (AC Gas Leak)
            </button>
            <button
              type="button"
              onClick={() => selectSampleId('FX-2026-7254')}
              className={`px-2.5 py-1 rounded-lg border font-mono text-[11px] transition-colors cursor-pointer whitespace-nowrap ${
                searchId === 'FX-2026-7254' ? 'bg-indigo-50 border-indigo-300 text-indigo-700 font-bold' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              FX-2026-7254 (Scholarship)
            </button>
          </div>

          {/* Ticket Details Box */}
          {currentRecord && (
            <div className="border border-slate-200 rounded-2xl p-5 bg-white space-y-4 shadow-xs">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                <div>
                  <span className="font-mono text-xs font-bold text-indigo-600">
                    {currentRecord.trackingId}
                  </span>
                  <h4 className="font-['Outfit',sans-serif] text-base font-bold text-slate-900 mt-0.5">
                    {currentRecord.title}
                  </h4>
                </div>

                <span className={`inline-flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full border self-start sm:self-center capitalize ${getStatusBadge(currentRecord.status)}`}>
                  <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                  {currentRecord.status.replace('_', ' ')}
                </span>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 font-medium block text-[10px] uppercase">
                    Department / Provider
                  </span>
                  <span className="font-semibold text-slate-800 mt-0.5 block line-clamp-1">
                    {currentRecord.departmentOrProvider}
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-400 font-medium block text-[10px] uppercase">
                    Estimated Time
                  </span>
                  <span className="font-semibold text-emerald-700 mt-0.5 block line-clamp-1">
                    {currentRecord.estimatedResolution}
                  </span>
                </div>
              </div>

              {/* Interactive Timeline */}
              <div className="pt-2">
                <h5 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                  Resolution Milestones
                </h5>

                <div className="relative pl-6 space-y-5 before:content-[''] before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                  {currentRecord.timeline.map((item, idx) => (
                    <div key={idx} className="relative">
                      {/* Node circle */}
                      <div className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        item.completed 
                          ? 'bg-emerald-500 text-white shadow-xs' 
                          : item.current 
                            ? 'bg-indigo-600 text-white animate-pulse ring-4 ring-indigo-100' 
                            : 'bg-slate-200 text-slate-500'
                      }`}>
                        {item.completed ? '✓' : idx + 1}
                      </div>

                      <div>
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-bold ${item.completed || item.current ? 'text-slate-900' : 'text-slate-400'}`}>
                            {item.title}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {item.timestamp}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* Phase 4 notice */}
          <div className="p-3.5 rounded-xl bg-indigo-50/70 border border-indigo-100 text-xs text-indigo-900 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600 flex-shrink-0 mt-0.5" />
            <p>
              <span className="font-semibold">Phase 1 Architecture:</span> This visual tracking engine establishes the schema and status models. Phase 4 will introduce automated SMS notifications, live GPS technician tracking, and nodal officer dashboards.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
