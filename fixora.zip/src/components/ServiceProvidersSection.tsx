import React, { useState } from 'react';
import { 
  SAMPLE_SERVICE_PROFESSIONALS 
} from '../data/mockData';
import { 
  ServiceProfessional 
} from '../types';
import { 
  Wrench, 
  Star, 
  ShieldCheck, 
  Clock, 
  ArrowRight, 
  Search, 
  UserCheck,
  CheckCircle,
  Briefcase
} from 'lucide-react';

interface ServiceProvidersSectionProps {
  onFindService: () => void;
  onBookProfessional: (pro: ServiceProfessional) => void;
}

export const ServiceProvidersSection: React.FC<ServiceProvidersSectionProps> = ({
  onFindService,
  onBookProfessional,
}) => {
  const [selectedTrade, setSelectedTrade] = useState<string>('all');

  const trades = [
    { id: 'all', label: 'All Trades' },
    { id: 'electrician', label: 'Electrician' },
    { id: 'plumber', label: 'Plumber' },
    { id: 'ac', label: 'AC Technician' },
    { id: 'carpenter', label: 'Carpenter' },
    { id: 'cleaner', label: 'Cleaner' },
    { id: 'refrigerator', label: 'Refrigerator' },
    { id: 'painter', label: 'Painter' },
    { id: 'cook', label: 'Cook' },
  ];

  const filteredPros = SAMPLE_SERVICE_PROFESSIONALS.filter((pro) => {
    if (selectedTrade === 'all') return true;
    return pro.category.toLowerCase().includes(selectedTrade.toLowerCase());
  });

  return (
    <section id="services" className="py-16 sm:py-20 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
          <div>
            <span className="text-xs font-bold text-indigo-600 tracking-wider uppercase bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
              Skilled Workforce
            </span>
            <h2 className="font-['Outfit',sans-serif] text-3xl sm:text-4xl font-extrabold text-slate-900 mt-2 tracking-tight">
              Need a Service Professional?
            </h2>
            <p className="text-base text-slate-600 mt-2 max-w-xl font-normal">
              Connect with vetted local electricians, plumbers, carpenters, technicians, cleaners, and household specialists with verified credentials.
            </p>
          </div>

          <div className="mt-4 md:mt-0">
            <button
              onClick={onFindService}
              className="px-6 py-3 rounded-xl font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span>Find a Service</span>
            </button>
          </div>
        </div>

        {/* Trade Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 scrollbar-none">
          {trades.map((trade) => (
            <button
              key={trade.id}
              onClick={() => setSelectedTrade(trade.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                selectedTrade === trade.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {trade.label}
            </button>
          ))}
        </div>

        {/* Professionals Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredPros.map((pro) => (
            <div
              key={pro.id}
              className="bg-white rounded-2xl border border-slate-200/90 hover:border-indigo-300 hover:shadow-lg transition-all duration-200 p-5 flex flex-col justify-between group"
            >
              <div>
                {/* Card Top Avatar & Availability */}
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 text-white font-bold flex items-center justify-center text-base shadow-xs">
                    {pro.name.charAt(0)}
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/70">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      {pro.availability}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400 mt-1">
                      {pro.startingRate}
                    </span>
                  </div>
                </div>

                {/* Name & Role */}
                <div className="flex items-center gap-1.5">
                  <h3 className="font-['Outfit',sans-serif] text-base font-bold text-slate-900 line-clamp-1">
                    {pro.name}
                  </h3>
                  {pro.verified && (
                    <span title="Fixora Verified Professional" className="inline-flex">
                      <ShieldCheck className="w-4 h-4 text-blue-600 flex-shrink-0" />
                    </span>
                  )}
                </div>
                <p className="text-xs font-medium text-slate-500 line-clamp-1 mt-0.5">
                  {pro.role}
                </p>

                {/* Rating & Experience */}
                <div className="flex items-center gap-3 mt-3 py-1.5 px-2.5 bg-slate-50 rounded-lg text-xs">
                  <div className="flex items-center gap-1 text-amber-600 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{pro.rating}</span>
                    <span className="text-slate-400 font-normal">({pro.reviewsCount})</span>
                  </div>
                  <span className="text-slate-300">|</span>
                  <div className="text-slate-600 text-[11px]">
                    {pro.experienceYears}+ yrs exp
                  </div>
                </div>

                {/* Skills tags */}
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {pro.skills.slice(0, 3).map((skill, i) => (
                    <span
                      key={i}
                      className="text-[10px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Action */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-medium">Phase 1 Preview</span>
                <button
                  onClick={() => onBookProfessional(pro)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-600 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span>Request Help</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Phase Architecture Note */}
        <div className="mt-8 text-center">
          <p className="text-xs text-slate-400">
            * Fixora service professional booking is in Phase 1 Preview mode. Full matching and scheduling workflows activate in Phase 3.
          </p>
        </div>

      </div>
    </section>
  );
};
