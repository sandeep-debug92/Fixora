import React, { useState, useMemo } from 'react';
import { Search, X, Sparkles, ArrowRight, CornerDownLeft, Shield, AlertTriangle } from 'lucide-react';
import { CATEGORIES, SEARCH_SUGGESTIONS } from '../data/categories';
import { SubCategory, Category } from '../types';

interface SearchBarProps {
  onSelectSubcategory: (category: Category, subcategory: SubCategory) => void;
  onOpenReportWithQuery: (query: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  onSelectSubcategory,
  onOpenReportWithQuery,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  // Flatten all subcategories for instant smart search
  const allSubcategories = useMemo(() => {
    const list: { category: Category; subcategory: SubCategory }[] = [];
    CATEGORIES.forEach((cat) => {
      cat.subcategories.forEach((sub) => {
        list.push({ category: cat, subcategory: sub });
      });
    });
    return list;
  }, []);

  // Filter based on query
  const matchingResults = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return [];

    return allSubcategories.filter(
      (item) =>
        item.subcategory.name.toLowerCase().includes(query) ||
        item.subcategory.description.toLowerCase().includes(query) ||
        item.category.name.toLowerCase().includes(query) ||
        item.subcategory.departmentOrIndustry?.toLowerCase().includes(query)
    ).slice(0, 6);
  }, [searchQuery, allSubcategories]);

  const handleSuggestionClick = (promptText: string) => {
    setSearchQuery(promptText);
    setIsFocused(true);
  };

  const handleClear = () => {
    setSearchQuery('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (matchingResults.length > 0) {
      onSelectSubcategory(matchingResults[0].category, matchingResults[0].subcategory);
    } else if (searchQuery.trim()) {
      onOpenReportWithQuery(searchQuery);
    }
  };

  return (
    <div className="relative max-w-4xl mx-auto px-4 sm:px-6 -mt-6 sm:-mt-8 z-30">
      <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/70 border border-slate-200 p-3 sm:p-4 transition-all">
        
        {/* Search Input Form */}
        <form onSubmit={handleSubmit} className="relative flex items-center">
          <div className="absolute left-3.5 sm:left-4 text-indigo-600 flex items-center pointer-events-none">
            <Search className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>

          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            placeholder="Describe your problem… (e.g. AC is not cooling, road pothole, scholarship delay)"
            className="w-full pl-11 sm:pl-13 pr-24 sm:pr-32 py-3.5 sm:py-4 text-sm sm:text-base text-slate-800 placeholder-slate-400 bg-transparent rounded-xl focus:outline-none font-medium"
            aria-label="Describe your problem"
          />

          <div className="absolute right-2 flex items-center gap-1.5">
            {searchQuery && (
              <button
                type="button"
                onClick={handleClear}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors mr-1"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              type="submit"
              className="px-4 sm:px-5 py-2 sm:py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all flex items-center gap-1.5"
            >
              <span>Search</span>
              <ArrowRight className="w-3.5 h-3.5 hidden sm:inline" />
            </button>
          </div>
        </form>

        {/* Live Matching Dropdown */}
        {searchQuery.trim().length > 0 && isFocused && (
          <div className="mt-3 pt-3 border-t border-slate-100 animate-in fade-in duration-150">
            <div className="flex items-center justify-between px-2 pb-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
              <span>Matching Categories in Fixora</span>
              <span>{matchingResults.length} relevant found</span>
            </div>

            {matchingResults.length > 0 ? (
              <div className="divide-y divide-slate-100">
                {matchingResults.map(({ category, subcategory }) => (
                  <button
                    key={subcategory.id}
                    onClick={() => {
                      onSelectSubcategory(category, subcategory);
                      setIsFocused(false);
                    }}
                    className="w-full py-2.5 px-3 rounded-lg hover:bg-slate-50 text-left transition-colors flex items-center justify-between group cursor-pointer"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">
                          {subcategory.name}
                        </span>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${category.colorScheme.badge}`}>
                          {category.name}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 line-clamp-1">
                        {subcategory.description}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 pl-4 flex-shrink-0">
                      <span className="text-[11px] font-medium text-slate-400 hidden sm:inline">
                        {subcategory.estimatedResolutionTime}
                      </span>
                      <span className="text-xs font-semibold text-indigo-600 group-hover:translate-x-0.5 transition-transform">
                        Select →
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center">
                <p className="text-sm text-slate-600 font-medium">
                  No exact category matched “{searchQuery}”
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Don’t worry — Fixora's Smart Triage will automatically route your issue.
                </p>
                <button
                  type="button"
                  onClick={() => onOpenReportWithQuery(searchQuery)}
                  className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 text-xs font-semibold transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Report “{searchQuery}” as a General Request</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Example Problem Chips */}
        <div className="mt-3 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs text-slate-500 scrollbar-none">
            <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px] flex-shrink-0">
              Try searching:
            </span>
            {SEARCH_SUGGESTIONS.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSuggestionClick(item.label)}
                className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 transition-colors font-medium text-xs whitespace-nowrap"
              >
                “{item.label}”
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
