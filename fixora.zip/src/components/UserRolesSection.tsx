import React from 'react';
import { USER_ROLES_INFO } from '../data/mockData';
import { UserRole } from '../types';
import { 
  Users, 
  Briefcase, 
  Building2, 
  ShieldCheck, 
  ArrowRight, 
  Layers,
  Check
} from 'lucide-react';

interface UserRolesSectionProps {
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  onOpenRoleModal: (role: UserRole) => void;
}

export const UserRolesSection: React.FC<UserRolesSectionProps> = ({
  currentRole,
  onSelectRole,
  onOpenRoleModal,
}) => {
  const getIconForRole = (role: UserRole) => {
    switch (role) {
      case 'citizen': return Users;
      case 'provider': return Briefcase;
      case 'authority': return Building2;
      case 'admin': return ShieldCheck;
    }
  };

  return (
    <section className="py-16 sm:py-20 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold text-indigo-600 tracking-wider uppercase bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
            Multi-Stakeholder Architecture
          </span>
          <h2 className="font-['Outfit',sans-serif] text-3xl sm:text-4xl font-extrabold text-slate-900 mt-3 tracking-tight">
            Built for 4 Core Fixora Personas
          </h2>
          <p className="text-base text-slate-600 mt-3 font-normal">
            Fixora is engineered from the ground up to accommodate citizens, tradespeople, municipal departments, and administrators in a single connected pipeline.
          </p>
        </div>

        {/* 4 Role Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {USER_ROLES_INFO.map((item) => {
            const Icon = getIconForRole(item.role);
            const isActive = currentRole === item.role;

            return (
              <div
                key={item.role}
                className={`bg-white rounded-2xl border p-6 flex flex-col justify-between transition-all duration-200 ${
                  isActive 
                    ? 'border-indigo-600 shadow-md ring-2 ring-indigo-500/20' 
                    : 'border-slate-200 hover:border-slate-300 hover:shadow-md'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                      isActive ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700'
                    }`}>
                      <Icon className="w-5 h-5 stroke-[2.2]" />
                    </div>
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="font-['Outfit',sans-serif] text-lg font-bold text-slate-900">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                    {item.desc}
                  </p>

                  {/* Capabilities preview */}
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
                    {item.features.map((feat, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-slate-600">
                        <Check className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                        <span className="line-clamp-1">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-3 border-t border-slate-100 space-y-2">
                  <button
                    onClick={() => onSelectRole(item.role)}
                    className={`w-full py-2 px-3 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                    }`}
                  >
                    <span>{isActive ? 'Active Mode' : 'Switch Mode'}</span>
                  </button>

                  <button
                    onClick={() => onOpenRoleModal(item.role)}
                    className="w-full text-center text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 py-1"
                  >
                    View Portal Roadmap →
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
