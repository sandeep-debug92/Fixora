export type UserRole = 'citizen' | 'provider' | 'authority' | 'admin';

export interface SubCategory {
  id: string;
  name: string;
  description: string;
  icon?: string;
  type: 'service' | 'public_issue' | 'government' | 'utility' | 'education' | 'general';
  estimatedResolutionTime?: string;
  departmentOrIndustry?: string;
}

export interface Category {
  id: string;
  name: string;
  tagline: string;
  iconName: string;
  colorScheme: {
    bg: string;
    text: string;
    border: string;
    badge: string;
    accent: string;
  };
  subcategories: SubCategory[];
}

export interface ProblemReportDraft {
  category: string;
  subcategory: string;
  title: string;
  description: string;
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  location: string;
  city: string;
  contactName: string;
  contactPhone: string;
  photoAttached?: boolean;
}

export interface TrackingRecord {
  trackingId: string;
  title: string;
  category: string;
  subcategory: string;
  status: 'submitted' | 'assigned' | 'in_progress' | 'resolved';
  departmentOrProvider: string;
  reportedDate: string;
  updatedDate: string;
  estimatedResolution: string;
  location: string;
  timeline: {
    step: number;
    title: string;
    desc: string;
    timestamp: string;
    completed: boolean;
    current?: boolean;
  }[];
}

export interface ServiceProfessional {
  id: string;
  name: string;
  role: string;
  category: string;
  rating: number;
  reviewsCount: number;
  experienceYears: number;
  verified: boolean;
  availability: 'Available Today' | 'Next Day' | 'On Call';
  skills: string[];
  startingRate: string;
}

export interface PublicIssueItem {
  id: string;
  title: string;
  category: string;
  location: string;
  reportedAgo: string;
  upvotes: number;
  status: 'Reported' | 'Inspected' | 'Work In Progress' | 'Resolved';
  icon: string;
}
